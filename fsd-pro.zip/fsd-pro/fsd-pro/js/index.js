const token = localStorage.getItem('token');

if (!token) {
    alert('Access denied. Please log in first.');
    window.location.href = '/login/login.html';
} else {
    fetch('/index.html', {
        headers: {
            'Authorization': token
        }
    })
    .then(response => {
        if (!response.ok) {
            alert('Access denied. Invalid token.');
            window.location.href = '/login/login.html';
        }
    })
    .catch(err => console.error('Error accessing the protected page:', err));
}
