document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const username = document.querySelector('input[name="username"]').value;
    const password = document.querySelector('input[name="password"]').value;

    fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.token) {
            // Store the JWT token in localStorage
            localStorage.setItem('token', data.token);
            // Redirect to the protected home page
            window.location.href = '/index.html';
        } else {
            alert('Login failed: ' + data.message);
        }
    })
    .catch(err => console.error('Error logging in:', err));
});
